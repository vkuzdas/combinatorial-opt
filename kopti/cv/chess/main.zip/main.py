#!/usr/bin/env python3
import sys

import gurobipy as g


if __name__ == '__main__':

    inFile, outFile = sys.argv[1:]
    file = open(inFile, 'r')
    # first line is number of following lines
    n = int(file.readline())
    rooks = []
    for i in range(n):
        chess_pos = file.readline().split()[0]
        x = ord(chess_pos[0])-ord('a')+2
        y = int(chess_pos[1])+1
        rooks.append((x,y))





    m = g.Model('chess')

    # abychom neresili edge cases, roztahneme sachonici
    # o 2 policka na kazde strane
    dim = 8+4
    # Create variables
    k = m.addVars(dim, dim, vtype=g.GRB.BINARY, name='horse')
    M = 8

    # radek falsu o dim bunkach
    # dim-krat radek falsu
    is_rook = [ [False for _ in range(dim)]  for _ in range(dim)  ]

    for x, y in rooks:
        # SWAPPED X/Y
        is_rook[y][x] = True
        m.addConstr(k.sum(y, '*') == 0, name='no_rook_threat')
        m.addConstr(k.sum('*', x) == 0, name='no_rook_threat')



    # Create constraints


    for i in range(2, dim-2):
        for j in range(2, dim-2):
            if is_rook[i][j]:
                # pokud je na policku vez, nesmi byt na sousednich polickach kun
                # m.addConstr(k.sum(i,'*') == 0, name='no_rook_threat')
                # m.addConstr(k.sum('*',i) == 0, name='no_rook_threat')
                continue
            else:
                # kdyz je na policku kun, nesmi ohrozovat jineho kone
                m.addConstr(M*(1-k[i,j]) >=
                            k[i-2,j-1] + k[i-2,j+1]
                            + k[i-1,j+2] + k[i+1,j+2]
                            + k[i+2,j+1] + k[i+2,j-1]
                            + k[i-1,j-2] + k[i+1,j-2], name='no_horse_threat')


    m.addConstr(k.sum(0, '*') == 0, 'empty_edges')
    m.addConstr(k.sum(1, '*') == 0, 'empty_edges')
    m.addConstr(k.sum(dim-1, '*') == 0, 'empty_edges')
    m.addConstr(k.sum(dim-2, '*') == 0, 'empty_edges')
    m.addConstr(k.sum('*', 0) == 0, 'empty_edges')
    m.addConstr(k.sum('*', 1) == 0, 'empty_edges')
    m.addConstr(k.sum('*', dim-1) == 0, 'empty_edges')
    m.addConstr(k.sum('*', dim-2) == 0, 'empty_edges')

    m.setObjective(g.quicksum(k[i,j] for i in range(2, dim-2) for j in range(2, dim-2)), g.GRB.MAXIMIZE)

    m.optimize()

    board = [['_' for _ in range(dim)] for _ in range(dim)]
    for i in range(2, dim-2):
        for j in range(2, dim-2):
            if is_rook[i][j]:
                board[i][j] = 'T'
                # print('T', end=' ')
                continue
            if k[i,j].x == 1:
                board[i][j] = 'H'
                # print('H', end=' ')
                continue
            else:
                # print('.', end=' ')
                continue
        print()

    res = []
    for i in range(2, dim-2):
        for j in range(2, dim-2):
            if board[i][j] == 'H':
                res.append((chr(j-2+ord('a')),i-1))
            print(board[i][j], end=' ')
        print()


    print(len(res))
    for tup in res:
        print(tup[0]+str(tup[1]))

    f = open(outFile, 'w')
    f.write(str(len(res)))
    for tup in res:
        # write on each line
        f.write('\n')
        f.write(tup[0]+str(tup[1]))
    f.close()
